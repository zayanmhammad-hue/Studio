# LXSTRZG Scuba Diving System

Custom water and scuba diving with a speargun for Roblox, by lxstrzg studios. More at lxstrzgstudios.com.

The sea is its own water, not Roblox Terrain water. Swimmers push its surface into bow waves, wakes and foam; from
below you see the sun through the waves. Under water there are three zones, each with its own fog, light, colour,
caustics on the floor, light shafts, drifting particles and sound: the sunny Coral Shallows, the Kelp Forest (the kelp
sways and parts round you) and The Abyss, where your lamp comes on. Players swim on their own avatar as an R6 diver with
a tank, flippers and a speargun, aim over the shoulder and fire spears that fly, stick and pierce, checked by the
server. It plays on PC, mobile and gamepad, and steps its quality down on its own on slower devices.

## What's inside

- `LXSTRZG_ScubaDiving.rbxl`: a ready place with the system installed and the showroom: land in the baseplate look,
  and a sea floor that steps down through all three zones to a trench 220 studs deep. Open it and press Play. To
  publish it as your own game, first turn on the Mesh / Image APIs (see "Before you publish").
- `LXSTRZG_ScubaDiving.rbxm`: the system on its own, for a game you already have. One `LXSTRZG_ScubaDiving` folder
  holding a folder for each place its parts go: `ReplicatedStorage`, `ServerScriptService`, `StarterPlayerScripts`,
  `StarterPlayer` (the R6 `StarterCharacter`) and `ServerStorage` (the diver's animations to save, see below).
- `Screenshots/`: the listing images.

## Install into your own game

1. In Studio, right-click ServerStorage in the Explorer, choose Insert from File and pick `LXSTRZG_ScubaDiving.rbxm`
   (nothing runs from ServerStorage, so nothing starts before it's in place).
2. Move the contents of each folder into the place it's named after: `ReplicatedStorage` and `ServerScriptService`
   into those services, `StarterPlayerScripts` into the folder of that name under StarterPlayer,
   `StarterPlayer/StarterCharacter` into StarterPlayer, and `LXSTRZG_DivingAnimations` into ServerStorage. Then delete
   the empty `LXSTRZG_ScubaDiving` folder.
3. Every player now spawns as the R6 diver body, dressed in their own avatar, with the tank, flippers and speargun.
4. Tell the water where your sea is (next section). Until you do, Output says "No water yet" when you press Play.
5. Before you publish, turn on the Mesh / Image APIs and save the diver's animations to Roblox (both below).

## Before you publish: turn on the Mesh / Image APIs

The sea's surface and its light are built at runtime with Roblox's EditableMesh and EditableImage, and Roblox blocks
those in any game saved to Roblox until you allow them. In Studio, open Experience Settings, go to Security and turn on
**Allow Mesh / Image APIs**, then Save (or on the Creator Dashboard: your game's Configure > Settings > **Enable Mesh /
Image APIs**). Without it the sea has no surface and Output says "EditableMesh is not accessible". A place that is only
a file on your computer (never saved to Roblox) doesn't need it.

## Your sea

Open `ReplicatedStorage.LXSTRZG_DivingConfig.WaterBodies` and list each water area:

```lua
return {
	{ min = Vector2.new(-1000, -1000), max = Vector2.new(1000, 1000), y = 0 },
}
```

`min` and `max` are the area's corners on the ground (x, z) and `y` is the water's surface. The ground under the water
must sit below the surface: a default Baseplate's top is at y 0, so with a sea at y 0 delete the Baseplate or dig your
sea floor below it. Parts above the surface stay dry land; swim into a low ledge to climb out.

## The diver's animations (needed for published games and for other players)

The diver's swim, tread and gun clips are built in code. Roblox only plays clips built that way inside Studio, and only
for your own diver, so a published game, and every other player watching you, needs them uploaded under your account
or group:

1. In ServerStorage, open `LXSTRZG_DivingAnimations`. It holds one KeyframeSequence per clip (12).
2. Right-click a clip and choose Save to Roblox. Roblox gives you its animation id.
3. Paste that id into the AnimationId of the Animation with the same name in
   `ReplicatedStorage.LXSTRZG_Diving.AnimationIds`.

The diver plays a filled slot first and the built-in clip for any slot left empty. Upload them under the same owner as
the game (your account, or the group that owns it). When you update the system later, keep your `AnimationIds` folder.

## Controls

| | Keyboard | Gamepad | Touch |
|---|---|---|---|
| Swim where you aim | W | left stick | move stick |
| Back-fin (slow) | S | left stick | move stick |
| Fin sideways | A / D | left stick | move stick |
| Rise / sink | Space / LeftControl or C | A / L2 | Up / Down buttons |
| Fin hard (hold) | LeftShift | X | Fin button |
| Tight aim (hold) | right mouse | L1 | Aim button |
| Fire the speargun | left mouse | R2 | Fire button |
| Look | mouse | right stick | drag |

On land the speargun rides on the right hip and you walk as usual. In the water the gun comes up into both hands, the
camera goes over your right shoulder with an aiming circle, and the diver faces where you look. Swimming forward lays
the body along your aim; stop and you tread water upright. At the surface you float; aim down and swim, or hold Down,
to dive.

## Hitting things with the speargun

Spears stick in anything they hit. To make them do something, tag a part (or the model it's in) `SpearTarget`, then
listen on the server:

```lua
local SpearHit = game:GetService("ServerStorage"):WaitForChild("LXSTRZG_DivingEvents"):WaitForChild("SpearHit")

SpearHit.Event:Connect(function(player, part, info)
	-- info.point, info.normal, info.dir: where and how it hit
	-- info.speed: studs/s at the hit; info.damage: 0-1, the share of a full-power shot
	local humanoid = part.Parent and part.Parent:FindFirstChildOfClass("Humanoid")
	if humanoid then
		humanoid:TakeDamage(40 * info.damage)
	end
end)
```

The server checks every shot a client claims (where it came from, how fast, whether the path could reach that point)
before it fires the event, so a hacked client can't hit what it couldn't have.

## Zones

| Zone | From | Look |
|---|---|---|
| Coral Shallows | the surface | sunlit cyan, bright caustics |
| Kelp Forest | 50 studs down | blue-green, kelp, softer light |
| The Abyss | 120 studs down | deep blue, specks, the lamp comes on |

- The depths are `Profiles.bands` in `ReplicatedStorage.LXSTRZG_Diving.Profiles`. Each zone's look is its entry in
  `Profiles.biomes` (fog, light falloff, colours, caustics, shafts, particles, current, sway, lamp).
- To add a zone: copy an entry in `Profiles.biomes` under a new name, add the name to `Profiles.order` and give it a
  band in `Profiles.bands`.
- A zone can also cover an area whatever its depth (a kelp cave, say): list a box in
  `LXSTRZG_DivingConfig.BiomeBoxes`, `{ name = "KelpForest", cframe = CFrame.new(x, y, z), size = Vector3.new(w, h, d) }`.
  Edges blend over 40 studs, so nothing switches on a hard line.

## More

- **Kelp:** any Model whose parts are kelp segments, tagged `LXSTRZG_DivingSway`, sways in the current and parts round
  divers. Copy a strand from the showroom's `Kelp` folder to start.
- **Things that push the water:** every diver does. Tag any other part `LXSTRZG_DivingBody` (a boat, a falling crate)
  and it makes waves too.
- **Quality:** High, Medium and Low, picked from the player's graphics level and stepped down when frames run slow.
  Phones start on Low. In Studio on High the water costs about 1.5 ms a frame at the surface and 2.3 ms among the kelp.
- **Speeds:** the Rubber Flippers swim at 14 studs/s, 21 finning hard, 5 backwards and 8 sideways
  (`DiverCore` in `LXSTRZG_Diving`).
- **The speargun's sounds** are free Creator Store sounds; swap any id in `SpearFX`.

## Licence

Free to use in your own Roblox games, including paid ones. See LICENSE.txt.
